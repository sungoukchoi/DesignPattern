package Practice;

public class Student {
	private String name;
	private String address;
	private String gender;
	private String department;
	private double grade; //����
	
	Student(String n, String a, String g, String d, double gr) { //������
		name = n;
		address = a;
		gender = g;
		department = d;
		grade = gr;
	}
	
	public void show() {
		System.out.printf("\n�̸� : %s\n������ : %s\n���� : %s\n���� : %s\n���� : %.2f\n", name, address, gender, department, grade);
	}
	
	public String getname() {
		return name;
	}
	
	public double getgrade() {
		return grade;
	}
	
	public void deletename() {
		name = "null";
	}
	
	public void setname(String n) {
		name = n;
	}
	
	public void setaddress(String a) {
		address = a;
	}

	public void setgender(String g) {
		gender = g;
	}
	
	public void setdepartment(String d) {
		department = d;
	}
	
	public void setgrade(double ge) {
		grade = ge;
	}
}
