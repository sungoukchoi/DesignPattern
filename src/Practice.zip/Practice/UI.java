package Practice;

import java.util.Scanner;

public class UI {
	public static void showmenu() {
		System.out.println("\n���ϴ� �۾��� �����Ͻÿ�.");
 		System.out.println("   [1] �л� �߰�");
 		System.out.println("   [2] �л� ����");
 		System.out.println("   [3] �л� ����");
 		System.out.println("   [4] �л� ��ü ��ȸ");
 		System.out.println("");
	 	System.out.print("   ���� (1, 2, 3, 4) : ");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		StudentManager StM = new StudentManager();
		int select;
		
		while(true) {
			UI.showmenu();
			select = sc.nextInt();
		
			switch(select) {
			case 1 :StM.addstudent(InputInfo.inputinfo());break;
			case 2 :StM.deletestudent();break;
			case 3 :StM.updatestudent();break;
			case 4 :StM.showallstudent();break;
			
			}
		}
	}

}
